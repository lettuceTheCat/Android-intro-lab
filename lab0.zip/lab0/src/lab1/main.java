/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1;

import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        System.out.println("For all the shapes we start with square, give your square a name first");
        String sq = in.nextLine();
        System.out.println("Give me the length of it:");
        double len = Double.parseDouble(in.nextLine());
        System.out.println("Give me the height of it:");
        double he = Double.parseDouble(in.nextLine());
        Square mySquare = new Square(sq);
        mySquare.setDimensions(len, he);
        mySquare.printDimensions();
        mySquare.printArea();
        System.out.println();/*only for goodlooking, blank line*/

        

        System.out.println("Next is circle, give me your circle's name");
        String circle = in.nextLine();
        System.out.println("What is the radius?");
        double R= Double.parseDouble(in.nextLine());
        Circle myCircle = new Circle(circle);
        myCircle.setDimensions(R);
        myCircle.printDimensions();
        myCircle.printArea();
        
        System.out.println();/*only for goodlooking, blank line*/
 
        
        System.out.println("Follow with triangle, give me your triangle's name: ");
        String tri = in.nextLine();
        System.out.println("Give me the first side length:");
        double s1 = Double.parseDouble(in.nextLine());
        System.out.println("Give me the second side length:");
        double s2 = Double.parseDouble(in.nextLine());
        System.out.println("Give me the third side length:");
        double s3 = Double.parseDouble(in.nextLine());
        
        while(s3 >= (s1 + s2) || s1 >= (s2 + s3) || s2 >= (s1 + s3)) {
            
            /*double check to make sure it can form a triangle using the 3 sides*/
            System.out.println("These 3 sides cannot form a triangle, please double check and try again:");
            System.out.println("Give me the first side length:");
            s1 = Double.parseDouble(in.nextLine());
            System.out.println("Give me the second side length:");
            s2 = Double.parseDouble(in.nextLine());
            System.out.println("Give me the third side length:");
            s3 = Double.parseDouble(in.nextLine());
        }
        Triangle myTriangle = new Triangle(tri);/*take the triangle you've just made */
        myTriangle.setDimensions(s1, s2, s3);
        myTriangle.printDimensions();
        myTriangle.printArea();
        System.out.println();/*only for goodlooking, blank line*/

        System.out.println("Finally is the special triangle, give me the name of your equilateral triangle:");
        String et = in.nextLine();
        System.out.println("Enter the side length:");
        double S = Double.parseDouble(in.nextLine());
        EquilateralTriangle myEquilateralTriangle = new EquilateralTriangle(et);
        myEquilateralTriangle.setDimensions(S);
        myEquilateralTriangle.printDimensions();
        myEquilateralTriangle.printArea();
        System.out.println();/*only for goodlooking, blank line*/
        
        
        
        System.exit(0);
    }
}
