/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1;

/**
 *
 * @author chizhang
 */
public class Triangle extends Shape {

    protected double s1, s2, s3;

    public Triangle(String name) {
        super(name);
    }


    public void setDimensions(double s1, double s2, double s3) {
        this.s1 = s1;
        this.s2 = s2;
        this.s3 = s3;
    }

    @Override
    public double getArea() {
        double s = (s1 + s2 + s3) * 0.5;
        return Math.sqrt(s * (s - s1) * (s - s2) * (s - s3));
    }

    @Override
    public void printDimensions() {
        System.out.println("The name of the triangle is " + getName());
        System.out.println("With first side length: " + s1 + ", second side length: " + s2 + ", third side length: " + s3);
    }

    public void printArea() {
        System.out.println("The area of the triangle "+ getName() + " is " + getArea());
    }
}
