/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1;

/**
 *
 * @author chizhang
 */
public class Square extends Shape {

    private double len, he;

    public Square(String name) {
        super(name);
    }

    public void setDimensions(double length, double height) {
        this.len = length;
        this.he = height;
    }

    @Override
    public double getArea() {
        return len * he;  // calculating the area using square formula
    }

    @Override
    public void printDimensions() {
        System.out.println("The name of the square is " + getName() );
        System.out.println("And its length is " + len + " with height of " + he);
    }
/* print out all the square parameters for getting the area, in here means length and height. */
    public void printArea() {
        System.out.println("The area of "+ getName() + " is " + getArea() );
        /*get the area using Area = length * height, square area formula*/
    }
}