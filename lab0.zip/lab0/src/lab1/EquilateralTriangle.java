/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1;

/**
 *
 * @author chizhang
 */
public class EquilateralTriangle extends Triangle {

    public EquilateralTriangle(String name) {
        super(name);
    }

    public void setDimensions(double s) {
        this.s1 = s;
        this.s2 = s;
        this.s3 = s;
    }

}

